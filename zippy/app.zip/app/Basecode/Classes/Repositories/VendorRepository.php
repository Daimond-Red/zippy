<?php

namespace App\Basecode\Classes\Repositories;

class VendorRepository extends Repository {

    public $model = '\App\User';

    public $viewIndex = 'admin.vendors.index';
    public $viewCreate = 'admin.vendors.create';
    public $viewEdit = 'admin.vendors.edit';
    public $viewShow = 'admin.vendors.show';

    public $storeValidateRules = [
        'first_name'    => 'required',
        'last_name'     => 'required',
        'email'         => 'required|email|unique:users,email',
        'password'      => 'required',
        'locations'     => 'required',
    ];

    public $updateValidateRules = [
        'first_name'    => 'required',
        'last_name'     => 'required',
        'email'         => 'required',
        'locations'     => 'required',
    ];

    public function getCollection() {
        $model = new $this->model;
        $model = $model->orderBy('created_at', 'desc')->where('role', \App\User::VENDOR);

        $whereLikefields = ['first_name', 'last_name', 'email', 'pancard_no', 'company_name', 'gstin' ];

        foreach ($whereLikefields as $field) {
            if( $value = request($field) ) $model = $model->where($field, 'like', '%'.$value.'%');
        }

        if(  array_key_exists('status', request()->all()) && request('status') == 0 ) $model = $model->where('status', 0);
        if( request('status') == 1 ) $model = $model->where('status', 1);

        return $model;
    }

    public function find( $id ) {
        $model = $this->model;
        $model = $model::find($id);
        if( $model->role != \App\User::VENDOR ) throw new  \Illuminate\Database\Eloquent\ModelNotFoundException;
        return $model;
    }

    public function save( $attrs ) {

        $model = new $this->model;
        $model->fill($attrs);

        $attrs['status'] = 0;
        if( isset($attrs['role']) ) $model->role = $attrs['role']; // it's needed

        $model->save();

        if( $areas = request('areas') ) $model->areas()->sync(explode(',', $areas));

        return $model;

    }

    public function update($model, $attrs = null) {

        if(! $attrs ) $attrs = $this->getAttrs();

        if( $areas = request('areas') ) {
            $model->areas()->sync(explode(',', $areas));
        } elseif( (!$areas = request('areas')) && array_key_exists('areas', $attrs) ) {
            $model->areas()->sync([]);
        }

        $model->fill($attrs);
        $model->update();

        return $model;

    }

    public function getAttrs()
    {

        $attrs = parent::getAttrs();
        $attrs['role'] = \App\User::VENDOR;

        if( $pass = request('password') ) $attrs['password'] = bcrypt($pass);

        $uploads = ['image'];

        foreach ( $uploads as $upload ) {

            if( request()->hasFile($upload) ){
                $attrs[$upload] = self::upload_file($upload, 'vendors');
            } elseif( $attrs && count($attrs) && array_key_exists($upload, $attrs) ) {
                unset($attrs[$upload]);
            }
        }

        return $attrs;

    }

    public function getRatting($id){
        $ids = \App\Driver::where('vendor_id', $id)->pluck('id')->toArray();
        $ratting = \App\ReviewRating::whereIn('rated_id', $ids)->where('type', 'driver')->avg('rating');
        return number_format($ratting, 1, '.', '');
    }

    public function parseModel($model)
    {
        $arr = [];

        $areas = [];
        foreach( $model->areas as $area ) {
            $areas[] = ['area_id' => $area->id, 'area_name' => $area->name, 'zipcode' => $area->zipcode];
        }

        $arr['vendor_id'] = (int)$this->prepare_field('id', $model);
        $arr['first_name'] = (string)$this->prepare_field('first_name', $model);
        $arr['last_name'] = (string)$this->prepare_field('last_name', $model);
        $arr['email'] = (string)$this->prepare_field('email', $model);
        $arr['mobile_no'] = (string) $this->prepare_field('mobile_no', $model);
        $arr['image'] = (string) $this->prepare_field('image', $model);
        $arr['locations'] = (string) $this->prepare_field('locations', $model);
        $arr['areas'] = $areas;
        $arr['rating'] = (string)$this->getRatting($model->id);
        $arr['pancard_no'] = (string)$this->prepare_field('pancard_no', $model);
        $arr['company_name'] = (string)$this->prepare_field('company_name', $model);
        $arr['gstin'] = (string)$this->prepare_field('gstin', $model);
        $arr['device_id'] = (string) $this->prepare_field('device_id', $model);
        $arr['device_type'] = (string)$this->prepare_field('device_type', $model);
        $arr['device_token'] = (string)$this->prepare_field('device_token', $model);
        $arr['status'] = (string) $this->prepare_field('status', $model);
        $arr['created_at'] = (string)$this->prepare_field('created_at', $model);

        return $arr;
    }

    public function isValidDriver($vendor_id, $driver_id) {

    }

    public function isValidVehicle($vendor_id, $driver_id) {

    }

}