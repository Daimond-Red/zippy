<?php

namespace App\Basecode\Classes\Repositories;

class VehicleRepository extends Repository {

    public $model = '\App\Vehicle';

    public $viewIndex = 'admin.vehicles.index';
    public $viewCreate = 'admin.vehicles.create';
    public $viewEdit = 'admin.vehicles.edit';
    public $viewShow = 'admin.vehicles.show';

    public $storeValidateRules = [

    ];

    public $updateValidateRules = [

    ];

    public function getAttrs()
    {
        $attrs = parent::getAttrs();

        $uploads = ['image', 'registration_pic'];

        foreach ( $uploads as $upload ) {
            if( request()->hasFile($upload) ){
                $attrs[$upload] = self::upload_file($upload, 'vendors');
            } elseif( $attrs && count($attrs) && array_key_exists($upload, $attrs) ) {
                unset($attrs[$upload]);
            }
        }

        return $attrs;

    }

}