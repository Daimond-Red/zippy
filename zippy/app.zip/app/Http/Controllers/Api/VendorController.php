<?php

namespace App\Http\Controllers\Api;

use App\Area;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Basecode\Classes\Repositories\VendorRepository;
use Illuminate\Support\Facades\Password;

class VendorController extends ApiController {

    public $vendorRepository;

    public function __construct( VendorRepository $vendorRepository ) {
        $this->vendorRepository = $vendorRepository;
    }

    public function register() {

        $rules = [
            'first_name'        => 'required|max:255|min:2',
            'last_name'         => 'required|max:255|min:2',
            'email'             => 'required|max:255|email',
            'mobile_no'         => 'required|digits:10|numeric',
            'password'          => 'required|max:500|min:4',
        ];

        if($err = $this->cvalidate($rules)) return $this->error($err, $err->first());

        $model = $this->vendorRepository->getModel()->whereEmail(request('email'))->first();
        if($model) return $this->error([], 'The email you entered already exists');

        $model = $this->vendorRepository->getModel()->whereMobileNo(request('mobile_no'))->first();
        if($model) return $this->error([], 'The mobile no. you entered already exists');

        $model = $this->vendorRepository->save($this->vendorRepository->getAttrs());

        return $this->data($this->vendorRepository->parseModel($model), 'Thank you for joining Zippy. Please wait while we verify your details and activate your account', 'vendor_details');

    }

    public function login() {

        $rules = [
            'password'      => 'required',
            'device_id'     => 'required',
            'device_type'   => 'required|in:android,ios',
            'device_token'  => 'required',
            'login_type'    => 'required|in:mobile,email',
        ];
        $field = '';
        if(request('login_type') == 'email'){ $rules['email'] = 'required|email';$field = 'email'; }
        if(request('login_type') == 'mobile'){ $rules['mobile_no'] = 'required|digits:10|numeric';$field = 'mobile_no'; }

        if ( $error = $this->cvalidate($rules) ) return $this->error($error, $error->first());

        if(! auth()->attempt([$field => request($field), 'password' => request('password'), 'role' => \App\User::VENDOR]) ) return $this->error([], 'The email or password you entered is incorrect');

        if(!auth()->user()->status) return $this->error([], 'Your account is still being verified by us. Please wait for some more time');

        $model = $this->vendorRepository->find(auth()->user()->id);
        $model = $this->vendorRepository->update($model, request()->only('device_id', 'device_type', 'device_token'));

        return $this->data($this->vendorRepository->parseModel($model), 'You are successfully logged in', 'vendor_details');

    }

    public function forgetPassword() {

        $user = $this->vendorRepository->getCollection()->whereEmail(request('email'))->first();

        if(!$user) return $this->error([], 'Invalid account details');

        try{

            $response = Password::broker()->sendResetLink(
                request()->only('email')
            );

        } catch (Exception $e){
//                echo $e->getMessage(); die;
            return $this->error([], 'We are unable to send email to your email address.');
        }

        return $this->data($this->vendorRepository->parseModel($user), 'An email has been send to given email id', 'vendor_details');

    }

    public function signout() {

        $rules = [ 'vendor_id' => 'required|exists:users,id' ];
        if ( $error = $this->cvalidate($rules) ) return $this->error($error, $error->first());

        $model = $this->vendorRepository->find(request('vendor_id'));

        $this->vendorRepository->update($model, ['device_id' => '', 'device_type' => '', 'device_token' => '']);

        return $this->data([], 'Logged out successfully', 'vendor_details');

    }

    public function updateProfile() {

        $rules = [ 'vendor_id' => 'required|exists:users,id' ];
        if ( $error = $this->cvalidate($rules) ) return $this->error($error, $error->first());

        $model = $this->vendorRepository->find(request('vendor_id'));

        $model = $this->vendorRepository->update($model, $this->vendorRepository->getAttrs());

        return $this->data($this->vendorRepository->parseModel($model), '', 'vendor_details');

    }

    public function getAreas() {
        $collection = Area::select('id as area_id', 'name', 'zipcode')->orderBy('created_at', 'desc')->get(['area_id', 'name', 'zipcode']);
        return $this->data($collection, '', 'get_areas');
    }
    
}
