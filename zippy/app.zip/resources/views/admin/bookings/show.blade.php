@extends('layouts.master')

@section('header')
    <div class="m-subheader ">
        <div class="d-flex align-items-center">
            <div class="mr-auto">
                <h3 class="m-subheader__title m-subheader__title--separator"> Booking Details </h3>
                <ul class="m-subheader__breadcrumbs m-nav m-nav--inline">
                    <li class="m-nav__item m-nav__item--home">
                        <a href="{{ route('admin.dashboard') }}" class="m-nav__link m-nav__link--icon">
                            <i class="m-nav__link-icon la la-home"></i>
                        </a>
                    </li>
                    <li class="m-nav__separator"> - </li>
                    <li class="m-nav__item">
                        <a href="{{route('admin.bookings.index')}}" class="m-nav__link">
                            <span class="m-nav__link-text">Bookings</span>
                        </a>
                    </li>
                    <li class="m-nav__separator"> - </li>
                    <li class="m-nav__item"><span class="m-nav__link-text">Booking Details</span></li>
                </ul>
            </div>
        </div>
    </div>
@stop

@section('content')
    <?php
    $customer = $model->customer;
    $vendor = null;
    $driver = null;
    $vehicle = null;

    if( $model->vendor ) $vendor = $model->vendor;
    if( $model->driver ) $driver = $model->driver;
    if( $model->vehicle ) $vehicle = $model->vehicle;

    ?>

    <div class="m-accordion m-accordion--default m-accordion--solid" id="m_accordion_5" role="tablist">

        <!--begin::Item-->
        <div class="m-accordion__item">
            <div class="m-accordion__item-head" role="tab" id="m_accordion_5_item_1_head" data-toggle="collapse" href="#vendors" aria-expanded="true">
                <span class="m-accordion__item-icon"><i class="fa flaticon-users"></i></span>
                <span class="m-accordion__item-title">Assigned Vendor</span>
                <span class="m-accordion__item-mode"><i class="la la-plus"></i></span>
            </div>
            <div class="m-accordion__item-body collapse show" id="vendors" role="tabpanel" aria-labelledby="m_accordion_5_item_1_head" data-parent="#m_accordion_5" style="">
                <span>
                    <div class="m-widget13">
                        <div class="m-widget13__item">
                            <span class="m-widget13__desc m--align-right">
                                Profile Image:
                            </span>
                            <span class="m-widget13__text m-widget13__text-bolder">
                                <img
                                        class="m-widget7__img"
                                        src="{{ getImageUrl($vendor->image) }}"
                                        alt=""
                                        style="width: 300px; height:300px"
                                >
                            </span>
                        </div>
                        <div class="m-widget13__item">
                            <span class="m-widget13__desc m--align-right">
                                Full Name:
                            </span>
                            <span class="m-widget13__text m-widget13__text-bolder">
                                {{ ucfirst($vendor->first_name). ' '. $vendor->last_name }}
                            </span>
                        </div>
                        <div class="m-widget13__item">
                            <span class="m-widget13__desc m--align-right">
                                Email:
                            </span>
                            <span class="m-widget13__text m-widget13__text-bolder">
                                {{ $vendor->email }}
                            </span>
                        </div>
                        <div class="m-widget13__item">
                            <span class="m-widget13__desc m--align-right">
                                Mobile No:
                            </span>
                            <span class="m-widget13__text m-widget13__text-bolder">
                                {{ $vendor->mobile_no }}
                            </span>
                        </div>
                        <div class="m-widget13__item">
                            <span class="m-widget13__desc m--align-right">
                                Pancard No:
                            </span>
                            <span class="m-widget13__text m-widget13__text-bolder">
                                {{ $vendor->pancard_no }}
                            </span>
                        </div>
                    </div>
                </span>
            </div>
        </div>
        <!--end::Item-->

        @if( $driver )
            <!--begin::Item-->
            <div class="m-accordion__item">
                <div class="m-accordion__item-head" role="tab" id="m_accordion_5_item_1_head" data-toggle="collapse" href="#driver" aria-expanded="true">
                    <span class="m-accordion__item-icon"><i class="fa flaticon-users"></i></span>
                    <span class="m-accordion__item-title">Driver</span>
                    <span class="m-accordion__item-mode"><i class="la la-plus"></i></span>
                </div>
                <div class="m-accordion__item-body collapse show" id="driver" role="tabpanel" aria-labelledby="m_accordion_5_item_1_head" data-parent="#m_accordion_5" style="">
            <span>
                <div class="m-widget13">
                    <div class="m-widget13__item">
                        <span class="m-widget13__desc m--align-right">
                            Image:
                        </span>
                        <span class="m-widget13__text m-widget13__text-bolder">
                            <img
                                class="m-widget7__img"
                                src="{{ getImageUrl($driver->image) }}"
                                alt=""
                                style="width: 300px; height:300px"
                            >
                        </span>
                    </div>
                    <div class="m-widget13__item">
                        <span class="m-widget13__desc m--align-right">
                            Full Name:
                        </span>
                        <span class="m-widget13__text m-widget13__text-bolder">
                            {{ ucfirst($driver->name) }}
                        </span>
                    </div>
                    <div class="m-widget13__item">
                        <span class="m-widget13__desc m--align-right">
                            Email:
                        </span>
                        <span class="m-widget13__text m-widget13__text-bolder">
                            {{ $driver->email }}
                        </span>
                    </div>
                    <div class="m-widget13__item">
                        <span class="m-widget13__desc m--align-right">
                            Mobile No:
                        </span>
                        <span class="m-widget13__text m-widget13__text-bolder">
                            {{ $driver->mobile }}
                        </span>
                    </div>
                    <div class="m-widget13__item">
                        <span class="m-widget13__desc m--align-right">
                            Licence No:
                        </span>
                        <span class="m-widget13__text m-widget13__text-bolder">
                            {{ $driver->licence_no }}
                        </span>
                    </div>
                </div>
            </span>
                </div>
            </div>
            <!--end::Item-->
        @endif

        @if( $vehicle )
            <!--begin::Item-->
            <div class="m-accordion__item">
                <div class="m-accordion__item-head" role="tab" id="m_accordion_5_item_1_head" data-toggle="collapse" href="#vendors" aria-expanded="true">
                    <span class="m-accordion__item-icon"><i class="fa flaticon-truck"></i></span>
                    <span class="m-accordion__item-title">Vehicle</span>
                    <span class="m-accordion__item-mode"><i class="la la-plus"></i></span>
                </div>
                <div class="m-accordion__item-body collapse show" id="vendors" role="tabpanel" aria-labelledby="m_accordion_5_item_1_head" data-parent="#m_accordion_5" style="">
            <span>
                <div class="m-widget13">
                    <div class="m-widget13__item">
                        <span class="m-widget13__desc m--align-right">
                            Image:
                        </span>
                        <span class="m-widget13__text m-widget13__text-bolder">
                            <img
                                    class="m-widget7__img"
                                    src="{{ getImageUrl($vehicle->image) }}"
                                    alt=""
                                    style="width: 300px; height:300px"
                            >
                        </span>
                    </div>
                    <div class="m-widget13__item">
                        <span class="m-widget13__desc m--align-right">
                            Registration no:
                        </span>
                        <span class="m-widget13__text m-widget13__text-bolder">
                            {{ $vehicle->registration_no }}
                        </span>
                    </div>
                    <div class="m-widget13__item">
                        <span class="m-widget13__desc m--align-right">
                            Owner name:
                        </span>
                        <span class="m-widget13__text m-widget13__text-bolder">
                            {{ $vehicle->owner_name }}
                        </span>
                    </div>
                    <div class="m-widget13__item">
                        <span class="m-widget13__desc m--align-right">
                            Owner mobile:
                        </span>
                        <span class="m-widget13__text m-widget13__text-bolder">
                            {{ $vehicle->owner_mobile }}
                        </span>
                    </div>
                    <div class="m-widget13__item">
                        <span class="m-widget13__desc m--align-right">
                            GPS:
                        </span>
                        <span class="m-widget13__text m-widget13__text-bolder">
                            @if (! $vehicle->gpsenabled )
                                <span class="m-badge  m-badge--danger m-badge--wide">No</span>
                            @else
                                <span class="m-badge m-badge--brand m-badge--wide">Yes</span>
                            @endif
                        </span>
                    </div>
                    <div class="m-widget13__item">
                        <span class="m-widget13__desc m--align-right">
                            No Entry:
                        </span>
                        <span class="m-widget13__text m-widget13__text-bolder">
                            @if (! $vehicle->noentrypermit )
                                <span class="m-badge  m-badge--danger m-badge--wide">No</span>
                            @else
                                <span class="m-badge m-badge--brand m-badge--wide">Yes</span>
                            @endif
                        </span>
                    </div>
                </div>
            </span>
                </div>
            </div>
            <!--end::Item-->
        @endif

        <!--begin::Item-->
        <div class="m-accordion__item">
            <div class="m-accordion__item-head" role="tab" id="m_accordion_5_item_1_head" data-toggle="collapse" href="#bookings" aria-expanded="true">
                <span class="m-accordion__item-icon"><i class="fa flaticon-route"></i></span>
                <span class="m-accordion__item-title">Bookings</span>
                <span class="m-accordion__item-mode"><i class="la la-plus"></i></span>
            </div>
            <div class="m-accordion__item-body collapse show" id="bookings" role="tabpanel" aria-labelledby="m_accordion_5_item_1_head" data-parent="#m_accordion_5" style="">
                <span>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="m-widget13">
                        <div class="m-widget13__item">
                            <span class="m-widget13__desc m--align-right">
                                Order ID:
                            </span>
                            <span class="m-widget13__text m-widget13__text-bolder">
                                {{ $model->id }}
                            </span>
                        </div>
                        <div class="m-widget13__item">
                            <span class="m-widget13__desc m--align-right">
                                Pickup Location:
                            </span>
                            <span class="m-widget13__text m-widget13__text-bolder">
                                {{ $model->pickup_address }}
                            </span>
                        </div>
                        <div class="m-widget13__item">
                            <span class="m-widget13__desc m--align-right">
                                Drop Location:
                            </span>
                            <span class="m-widget13__text m-widget13__text-bolder">
                                {{ $model->drop_address }}
                            </span>
                        </div>
                        <div class="m-widget13__item">
                            <span class="m-widget13__desc m--align-right">
                                Total Distance:
                            </span>
                            <span class="m-widget13__text m-widget13__text-bolder">
                                {{ $model->total_distance }}
                            </span>
                        </div>
                        <div class="m-widget13__item">
                            <span class="m-widget13__desc m--align-right">
                                Total Amount:
                            </span>
                            <span class="m-widget13__text m-widget13__text-bolder">
                                {{ $model->total_amount }}
                            </span>
                        </div>
                        <div class="m-widget13__item">
                            <span class="m-widget13__desc m--align-right">
                                Cargo Type:
                            </span>
                            <span class="m-widget13__text m-widget13__text-bolder">
                                {{ $model->cargo_type->title }}
                            </span>
                        </div>
                        <div class="m-widget13__item">
                            <span class="m-widget13__desc m--align-right">
                                Vehicle Type:
                            </span>
                            <span class="m-widget13__text m-widget13__text-bolder">
                                {{ $model->vehicle_type->title }}
                            </span>
                        </div>
                        <div class="m-widget13__item">
                            <span class="m-widget13__desc m--align-right">
                                Vehicle Category:
                            </span>
                            <span class="m-widget13__text m-widget13__text-bolder">
                                {{ $model->vehicle_category->title }}
                            </span>
                        </div>
                        <div class="m-widget13__item">
                            <span class="m-widget13__desc m--align-right">
                                Gross Weight:
                            </span>
                            <span class="m-widget13__text m-widget13__text-bolder">
                                {{ $model->gross_weight }}
                            </span>
                        </div>
                        <div class="m-widget13__item">
                            <span class="m-widget13__desc m--align-right">
                                Carton Length:
                            </span>
                            <span class="m-widget13__text m-widget13__text-bolder">
                                {{ $model->carton_lenght }}
                            </span>
                        </div>
                        <div class="m-widget13__item">
                            <span class="m-widget13__desc m--align-right">
                                Carton Breadth:
                            </span>
                            <span class="m-widget13__text m-widget13__text-bolder">
                                {{ $model->carton_breadth }}
                            </span>
                        </div>
                        <div class="m-widget13__item">
                            <span class="m-widget13__desc m--align-right">
                                Carton Height:
                            </span>
                            <span class="m-widget13__text m-widget13__text-bolder">
                                {{ $model->carton_height }}
                            </span>
                        </div>
                        <div class="m-widget13__item">
                            <span class="m-widget13__desc m--align-right">
                                Volume:
                            </span>
                            <span class="m-widget13__text m-widget13__text-bolder">
                                {{ $model->volume }}
                            </span>
                        </div>
                        <div class="m-widget13__item">
                            <span class="m-widget13__desc m--align-right">
                                Freight Cost:
                            </span>
                            <span class="m-widget13__text m-widget13__text-bolder">
                                {{ $model->freight_cost }}
                            </span>
                        </div>

                    </div>
                        </div>

                    </div>
                </span>
            </div>
        </div>
        <!--end::Item-->

        <!--begin::Item-->
        <div class="m-accordion__item">
            <div class="m-accordion__item-head collapsed" role="tab" id="m_accordion_5_item_3_head" data-toggle="collapse" href="#m_accordion_5_item_3_body" aria-expanded="    false">
                <span class="m-accordion__item-icon">
                    <i class="fa  flaticon-user"></i>
                </span>
                <span class="m-accordion__item-title">
                    Customer
                </span>
                <span class="m-accordion__item-mode">
                    <i class="la la-plus"></i>
                </span>
            </div>
            <div class="m-accordion__item-body collapse" id="m_accordion_5_item_3_body" role="tabpanel" aria-labelledby="m_accordion_5_item_3_head" data-parent="#m_accordion_5">
                <span>
                    <div class="m-widget13">
                        <div class="m-widget13__item">
                            <span class="m-widget13__desc m--align-right">
                                Profile Image:
                            </span>
                            <span class="m-widget13__text m-widget13__text-bolder">
                                <img
                                        class="m-widget7__img"
                                        src="{{ getImageUrl($customer->image) }}"
                                        alt=""
                                        style="width: 300px; height:300px"
                                >
                            </span>
                        </div>
                        <div class="m-widget13__item">
                            <span class="m-widget13__desc m--align-right">
                                Full Name:
                            </span>
                            <span class="m-widget13__text m-widget13__text-bolder">
                                {{ ucfirst($customer->first_name). ' '. $customer->last_name }}
                            </span>
                        </div>
                        <div class="m-widget13__item">
                            <span class="m-widget13__desc m--align-right">
                                Email:
                            </span>
                            <span class="m-widget13__text m-widget13__text-bolder">
                                {{ $customer->email }}
                            </span>
                        </div>
                        <div class="m-widget13__item">
                            <span class="m-widget13__desc m--align-right">
                                Mobile No:
                            </span>
                            <span class="m-widget13__text m-widget13__text-bolder">
                                {{ $customer->mobile_no }}
                            </span>
                        </div>
                        <div class="m-widget13__item">
                            <span class="m-widget13__desc m--align-right">
                                Pancard No:
                            </span>
                            <span class="m-widget13__text m-widget13__text-bolder">
                                {{ $customer->pancard_no }}
                            </span>
                        </div>
                    </div>
                </span>
            </div>
        </div>
        <!--end::Item-->

    </div>


@stop

@section('style')
    <style>
        .m-portlet.m-portlet--head-sm .m-portlet__head {
            height: 6.1rem;

        }
        .m-portlet:hover{
            box-shadow: 0px 3px 20px 0px #bdc3d4;
        }
        .m-radio.m-radio--state-primary > span{
            margin-top: 7%;
        }
        .m-portlet .m-portlet__body{
            padding-bottom: 0px;
        }
    </style>
@stop

@section('script')
    <script>
        $(document).ready(function(){
            $('.booking-menu').addClass('m-menu__item--submenu m-menu__item--open m-menu__item--expanded');
            $('.bookinglist-menu').addClass('m-menu__item--active');
        });
    </script>
@stop