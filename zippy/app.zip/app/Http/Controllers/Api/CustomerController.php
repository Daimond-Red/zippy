<?php

namespace App\Http\Controllers\Api;

use App\CargoType;
use App\User;
use App\VehicleCategory;
use App\VehicleType;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Basecode\Classes\Repositories\CustomerRepository;
use Illuminate\Support\Facades\Password;

class CustomerController extends ApiController {

    public $customerRepository;

    public function __construct( CustomerRepository $customerRepository ) {
        $this->customerRepository = $customerRepository;
    }

    public function register() {

        $attrs = request()->all();

        $rules = [
            'customer_type'       => 'required|in:1,2',
            'signup_type'       => 'required|in:facebook,gplus,normal',
            'first_name'        => 'required|max:255|min:2',
            'last_name'         => 'required|max:255|min:2',
            'email'             => 'required|max:255|email',
            'mobile_no'         => 'required|digits:10|numeric',
            'password'          => 'required|max:500|min:4',
        ];

        if($err = $this->cvalidate($rules)) return $this->error($err, $err->first());

        if( $attrs['signup_type'] == 'facebook' ) {

            if($err = $this->cvalidate(['facebook_id' => 'required'])) return $this->error($err, $err->first());

            $model = $this->customerRepository->getModel()->where(function($q){
                $q->orWhere('email', request('email'))->orWhere('mobile_no', request('mobile_no'))->orWhere('facebook_id', request('facebook_id'));
            })->first();

            if( $model ) $this->customerRepository->update($model, request()->only(['signup_type', 'facebook_id']));

        } elseif( $attrs['signup_type'] == 'gplus' ) {

            if($err = $this->cvalidate(['gplus_id' => 'required'])) return $this->error($err, $err->first());

            $model = $this->customerRepository->getModel()->where(function($q){
                $q->orWhere('email', request('email'))->orWhere('mobile_no', request('mobile_no'))->orWhere('gplus_id', request('gplus_id'));
            })->first();

            if( $model ) $this->customerRepository->update($model, request()->only(['signup_type', 'gplus_id']));

        } else {

            $model = $this->customerRepository->getModel()->whereEmail(request('email'))->first();
            if($model) return $this->error([], 'The email you entered already exists');

            $model = $this->customerRepository->getModel()->whereMobileNo(request('mobile_no'))->first();
            if($model) return $this->error([], 'The mobile no. you entered already exists');

        }

        if(! $model ) $model = $this->customerRepository->save($this->customerRepository->getAttrs());

        if(! $model->status ) $this->customerRepository->update($model, [ 'otp' => sendOtp($model->mobile_no), 'otp_created_at' => date('Y-m-d H:i:s') ]);

        return $this->data($this->customerRepository->parseModel($model), 'Account created successfully', 'customer_details');

	}

    public function verifyOtp() {

        $attrs = request()->all();

        if ( $error = $this->cvalidate( ['mobile_no' => 'required', 'otp' => 'required'] ) ) return $this->error($error, 'Validation fails');

        $model = $this->customerRepository->getCollection()->where('mobile_no', request('mobile_no'))->first();

        if(!$model) return $this->error([], 'This mobile number is not registered with us');

        $to_time = strtotime( date('Y-m-d H:i:s') );
        $from_time = strtotime( $model->otp_created_at );
        $diff = round(abs($to_time - $from_time) / 60,0);

        if(! ($attrs['otp'] == '1111' && config('app.debug')) ) {
            // otp will be expired after 5 minutes
            if( $diff > 5 ) return $this->error([], 'OTP expired');

            // both otp should be same
            if( $attrs['otp'] != $model->otp ) return $this->error([], 'Invalid OTP');

        }


        // this will enable model.
        $model->status = '1';
        $model->otp = '';
        $model->otp_created_at = null;
        $model->save();

        return $this->data($this->customerRepository->parseModel($model), 'Your OTP has been verified successfully', 'customer_details');

    }

    public function resentOtp() {

        $attrs = request()->all();

        if ( $error = $this->cvalidate( ['mobile_no' => 'required'] ) ) return $this->error($error, 'Validation fails');

        $model = $this->customerRepository->getCollection()->where('mobile_no', request('mobile_no'))->first();

        if(!$model) return $this->error([], 'Invalid account details');

        $model = $this->customerRepository->update($model, [ 'otp' => sendOtp($model->mobile_no), 'otp_created_at' => date('Y-m-d H:i:s') ]);

        return $this->data($this->customerRepository->parseModel($model), 'OTP has been sent to your mobile number', 'customer_details');

    }

	public function login() {
        $rules = [
            'password'      => 'required',
            'device_id'     => 'required',
            'device_type'   => 'required|in:android,ios',
            'device_token'  => 'required',
            'login_type'    => 'required|in:mobile,email',
        ];
        $field = '';
        if(request('login_type') == 'email'){ $rules['email'] = 'required|email';$field = 'email'; }
        if(request('login_type') == 'mobile'){ $rules['mobile_no'] = 'required|digits:10|numeric';$field = 'mobile_no'; }

        if ( $error = $this->cvalidate($rules) ) return $this->error($error, $error->first());

        if(! auth()->attempt([$field => request($field), 'password' => request('password'), 'role' => \App\User::CUSTOMER]) ) return $this->error([], 'The email or password you entered is incorrect');

        if(!auth()->user()->status) return $this->error([], 'your account is not verified yet');

        $model = $this->customerRepository->find(auth()->user()->id);
        $model = $this->customerRepository->update($model, request()->only('device_id', 'device_type', 'device_token'));

        return $this->data($this->customerRepository->parseModel($model), 'You are successfully logged in', 'customer_details');

	}

	public function forgetPassword() {

        $user = $this->customerRepository->getCollection()->whereEmail(request('email'))->first();

        if(!$user) return $this->error([], 'Invalid account details');

        try{

            $response = Password::broker()->sendResetLink(
                request()->only('email')
            );

        } catch (Exception $e){
//                echo $e->getMessage(); die;
            return $this->error([], 'We are unable to send email to your email address.');
        }

        return $this->data($this->customerRepository->parseModel($user), 'An email has been send to given email id', 'customer_details');

	}

    public function signout() {

        $rules = [ 'customer_id' => 'required|exists:users,id' ];
        if ( $error = $this->cvalidate($rules) ) return $this->error($error, $error->first());

        $model = $this->customerRepository->find(request('customer_id'));

        $this->customerRepository->update($model, ['device_id' => '', 'device_type' => '', 'device_token' => '']);

        return $this->data([], 'Logged out successfully', 'customer_details');

    }

    public function updateProfile() {

        $rules = [ 'customer_id' => 'required|exists:users,id' ];

        if ( $error = $this->cvalidate($rules) ) return $this->error($error, $error->first());

        $model = $this->customerRepository->find(request('customer_id'));

        if(!$model->status) return $this->error([], 'your account is not verified yet');

        $model = $this->customerRepository->update($model, $this->customerRepository->getAttrs());

        return $this->data($this->customerRepository->parseModel($model), '', 'customer_details');
        
    }

    public function typeOfCargos() {
        $collection = CargoType::select('id as cargo_type_id', 'title')->get(['cargo_type_id', 'title']);
        return $this->data($collection, '', 'type_of_cargos');
    }

    public function typeOfVehicleRequired() {
        $collection = VehicleType::select('id as vehicle_type_id', 'title')->get(['vehicle_type_id', 'title']);
        return $this->data($collection, '', 'type_of_vehicle_required');
    }

    public function vehicleCategories() {
        $collection = VehicleCategory::select('id as vehicle_category_id', 'title', 'image')->get(['vehicle_category_id', 'title', 'image']);
        return $this->data($collection, '', 'vehicle_categories');
    }

    public function suggestedVehicles() {
        $collection = VehicleCategory::get();
        return $this->data($collection, '', 'suggested_vehicles');
    }

    public function chooseVehicles() {
        $collection = VehicleCategory::get();
        return $this->data($collection, '', 'choose_vehicles');
    }

    public function getProfile() {

        $rules = [ 'email' => 'required|exists:users,email' ];

        if ( $error = $this->cvalidate($rules) ) return $this->error($error, $error->first());

        $model = $this->customerRepository->getCollection()->whereEmail(request('email'))->first();

        if(!$model) return $this->error([], 'Invalid email');

        return $this->data($this->customerRepository->parseModel($model));

    }

}