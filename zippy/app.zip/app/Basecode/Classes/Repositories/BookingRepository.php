<?php

namespace App\Basecode\Classes\Repositories;

use App\VehicleCategory;
use App\BookingLog;

class BookingRepository extends Repository {

    public $vehicleRepository,
        $vendorRepository,
        $customerRepository,
        $driverRepository,
        $cargoTypeRepository,
        $vehicleTypeRepository,
        $vehicleCategoryRepository,
        $bookingStatusRepository,
        $bookingStatusTrackerRepository;

    public function __construct(
        CustomerRepository $customerRepository,
        VendorRepository $vendorRepository,
        DriverRepository $driverRepository,
        VehicleRepository $vehicleRepository,
        CargoTypeRepository $cargoTypeRepository,
        VehicleTypeRepository $vehicleTypeRepository,
        VehicleCategoryRepository $vehicleCategoryRepository,
        BookingStatusRepository $bookingStatusRepository,
        BookingStatusTrackerRepository $bookingStatusTrackerRepository
    ) {
        $this->vehicleRepository = $vehicleRepository;
        $this->vendorRepository = $vendorRepository;
        $this->customerRepository = $customerRepository;
        $this->driverRepository = $driverRepository;
        $this->cargoTypeRepository = $cargoTypeRepository;
        $this->vehicleTypeRepository = $vehicleTypeRepository;
        $this->vehicleCategoryRepository = $vehicleCategoryRepository;
        $this->bookingStatusRepository = $bookingStatusRepository;
        $this->bookingStatusTrackerRepository = $bookingStatusTrackerRepository;
    }

    public $model = '\App\Booking';

    public $viewIndex = 'admin.bookings.index';
    public $viewCreate = 'admin.bookings.create';
    public $viewEdit = 'admin.bookings.edit';
    public $viewShow = 'admin.bookings.show';

    public $storeValidateRules = [
        'title' => 'required'
    ];

    public $updateValidateRules = [];

    public function getRelatedVendors($vehicleCategoryId) {
        $vendor_ids = $this->vehicleRepository->getCollection()->where('vehicle_category_id', $vehicleCategoryId)->pluck('vendor_id');
        return $this->vendorRepository->getCollection()->whereIn('id', $vendor_ids)->get();
    }

    public function getRelatedVehicleBookings($vendorId) {
        return $this->vehicleRepository->getCollection()->where('vendor_id', $vendorId)->distinct()->pluck('vehicle_category_id')->toArray();
    }

    public function getRelatedCancelVendor($vendorId) {
        return $this->bookingStatusTrackerRepository->getCollection()->where('user_id', $vendorId)->where('status', 3)->pluck('booking_id')->toArray();
    }

    public function getRelatedAcceptVendor($vendorId) {
        return BookingLog::where('vendor_id', $vendorId)->pluck('booking_id')->toArray();
    }

    public function getAttrs() {
        $attrs = parent::getAttrs();

        $vehicleCategory = VehicleCategory::find($attrs['vehicle_category_id']);

        $attrs['total_amount'] = ($vehicleCategory->price * $attrs['total_distance']) + request('freight_cost');

        return $attrs;
    }

    public function getCollection() {
        $model = new $this->model;

        $model = $model->with([
            'customer',
            'vendor',
            'driver',
            'vehicle',
            'cargo_type',
            'vehicle_type',
            'vehicle_category',
        ])->orderBy('created_at', 'desc');

        $whereLikefields = ['customer_id', 'vendor_id', 'status' ];

        foreach ($whereLikefields as $field) {
            if( $value = request($field) ) $model = $model->where($field, 'like', '%'.$value.'%');
        }

        if($value = request('start')) $model = $model->whereDate('created_at', '>=', $value);
        if($value = request('end'))   $model = $model->whereDate('created_at', '<=', $value);

        return $model;
    }

    public function getVendorLogIds($booking_id) {
        $model = $this->find($booking_id);
        $vendor_ids = [];
        foreach( $model->booking_logs as $log) $vendor_ids[] = $log->vendor_id;
        return $vendor_ids;
    }

    /**
     * THIS FUNCTION ACCEPT BOOKING ID
     * AND RETURN VENDOR COLLECTION LIST
     * THAT HAS APPLIED FOR THIS BOOKING
     */
    public function getVendorLogCollection($booking_id) {
        $vendor_ids = $this->getVendorLogIds($booking_id);
        return $this->vendorRepository->getCollection()->whereIn('id', $vendor_ids)->get();
    }

    public function parseModel($model) {

        $arr = [];
        $arr['booking_id']                  = (string)$this->prepare_field('id', $model);
        $arr['customer_id']                 = (string)$this->prepare_field('customer_id', $model);
        $arr['driver_id']                   = (string)$this->prepare_field('driver_id', $model);
        $arr['vehicle_id']                  = (string)$this->prepare_field('vehicle_id', $model);
        $arr['vendor_id']                   = (string)$this->prepare_field('vendor_id', $model);
        $arr['pickup_date']                   = (string)$this->prepare_field('pickup_date', $model);
        $arr['pickup_time']                   = (string)$this->prepare_field('pickup_time', $model);
        $arr['pickup_address']              = (string)$this->prepare_field('pickup_address', $model);
        $arr['pickup_coordinates']          = (string)$this->prepare_field('pickup_coordinates', $model);
        $arr['drop_address']                = (string)$this->prepare_field('drop_address', $model);
        $arr['drop_coordinates']            = (string)$this->prepare_field('drop_coordinates', $model);
        $arr['total_distance']              = (string)$this->prepare_field('total_distance', $model);
        $arr['total_amount']                = (string)$this->prepare_field('total_amount', $model);
        $arr['cargo_type_id']               = (string)$this->prepare_field('cargo_type_id', $model);
        $arr['vehicle_type_id']             = (string)$this->prepare_field('vehicle_type_id', $model);
        $arr['gross_weight']                = (string)$this->prepare_field('gross_weight', $model);
        $arr['carton_lenght']               = (string)$this->prepare_field('carton_lenght', $model);
        $arr['carton_breadth']              = (string)$this->prepare_field('carton_breadth', $model);
        $arr['carton_height']               = (string)$this->prepare_field('carton_height', $model);
        $arr['volume']                      = (string)$this->prepare_field('volume', $model);
        $arr['vehicle_category_id']         = (string)$this->prepare_field('vehicle_category_id', $model);
        $arr['freight_cost']                = (string)$this->prepare_field('freight_cost', $model);
        $arr['is_vendor_complete_status']   = (string)$this->prepare_field('is_vendor_complete_status', $model);
        $arr['status']                      = (string)$this->prepare_field('status', $model);
        $arr['created_at']                  = (string)$this->prepare_field('created_at', $model);

        $arr['customer'] = new \stdClass();
        $arr['vendor'] = new \stdClass();
        $arr['driver'] = new \stdClass();
        $arr['vehicle'] = new \stdClass();
        $arr['cargo_type'] = new \stdClass();
        $arr['vehicle_type'] = new \stdClass();
        $arr['vehicle_category'] = new \stdClass();
        $arr['booking_status'] = new \stdClass();

        if( isset($model->customer) && $model->customer ) $arr['customer'] = $this->customerRepository->parseModel($model->customer);
        if( isset($model->vendor) && $model->vendor ) $arr['vendor'] = $this->vendorRepository->parseModel($model->vendor);
        if( isset($model->driver) && $model->driver ) $arr['driver'] = $this->driverRepository->parseModel($model->driver);
        if( isset($model->vehicle) && $model->vehicle ) $arr['vehicle'] = $this->vehicleRepository->parseModel($model->vehicle);
        if( isset($model->cargo_type) && $model->cargo_type ) $arr['cargo_type'] = $this->cargoTypeRepository->parseModel($model->cargo_type);
        if( isset($model->vehicle_type) && $model->vehicle_type ) $arr['vehicle_type'] = $this->vehicleTypeRepository->parseModel($model->vehicle_type);
        if( isset($model->vehicle_category) && $model->vehicle_category ) $arr['vehicle_category'] = $this->vehicleCategoryRepository->parseModel($model->vehicle_category);
        if( isset($model->status) && $model->status) $arr['booking_status'] = $this->bookingStatusRepository->parseModel($model->booking_status);

        return $arr;

    }

}