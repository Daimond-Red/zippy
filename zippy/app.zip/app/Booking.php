<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Booking extends Model {

    const PENDING = 1;
    const ACCEPT = 2;
    const CANCEL = 3;
    const PROCESS = 4;
    const PICKUP = 5;
    const IN_TRANSIT = 6;
    const PAYMENT = 7;
const COMPLETE = 7;

    protected $fillable = [
        'customer_id',
        'vendor_id',
        'pickup_date',
        'pickup_time',
        'pickup_address',
        'pickup_coordinates',
        'drop_address',
        'drop_coordinates',
        'total_distance',
        'total_amount',
        'cargo_type_id',
        'vehicle_count',
        'vehicle_type_id',
        'gross_weight',
        'carton_lenght',
        'carton_breadth',
        'carton_height',
        'volume',
        'package_count',
        'vehicle_category_id',
        'freight_cost',
        'is_vendor_complete_status',
        'status',
    ];

    // 'customer', 'vendor', 'driver', 'vehicle', 'status'
    public function customer() {
        return $this->belongsTo(User::class);
    }

    public function vendor() {
        return $this->belongsTo(User::class);
    }

    public function driver() {
        return $this->belongsTo(Driver::class);
    }

    public function vehicle() {
        return $this->belongsTo(Vehicle::class);
    }

    public function cargo_type() {
        return $this->belongsTo(CargoType::class);
    }

    public function vehicle_type() {
        return $this->belongsTo(VehicleType::class);
    }

    public function vehicle_category() {
        return $this->belongsTo(VehicleCategory::class);
    }

    public function booking_logs() {
        return $this->hasMany(BookingLog::class);
    }

    public function booking_status() {
        return $this->belongsTo(BookingStatus::class, 'status');
    }

}
