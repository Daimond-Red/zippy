<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/



Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});


Route::group([ 'middleware' => 'api', 'prefix' => 'customers', 'namespace' => 'Api' ], function() {

// get pages
Route::post('get-page', 'PageController@index');

    // register
    Route::post('signup', 'CustomerController@register');

    // verify otp
    Route::post('verify-otp', 'CustomerController@verifyOtp');

    // resent otp
    Route::post('resend-otp', 'CustomerController@resentOtp');

    // login
    Route::post('signin', 'CustomerController@login');

    // forget password
    Route::post('forget-password', 'CustomerController@forgetPassword');

    // update customer profile
    Route::post('updateProfile', 'CustomerController@updateProfile');

    // signout customer
    Route::post('signout', 'CustomerController@signout');

    Route::post('getProfile', 'CustomerController@getProfile');

});

Route::group([ 'middleware' => 'api', 'prefix' => 'vendors', 'namespace' => 'Api' ], function() {

    // register
    Route::post('signup', 'VendorController@register');

    // login
    Route::post('signin', 'VendorController@login');

    // forget password
    Route::post('forget-password', 'VendorController@forgetPassword');

    // update profile
    Route::post('updateProfile', 'VendorController@updateProfile');

    // signout vendor
    Route::post('signout', 'VendorController@signout');

    // accepted booking
    // cancel
    // intransit
    // complete
    // history

});

Route::group([ 'middleware' => 'api', 'namespace' => 'Api' ], function() {

    // type of cargos
    Route::post('typeOfCargos', 'CustomerController@typeOfCargos');

    Route::post('typeOfVehicleRequired', 'CustomerController@typeOfVehicleRequired');

    Route::post('vehicleCategories', 'CustomerController@vehicleCategories');

    Route::post('suggestedVehicles', 'CustomerController@suggestedVehicles');

    Route::post('chooseVehicles', 'CustomerController@chooseVehicles');

    Route::post('getAreas', 'VendorController@getAreas');

});

Route::group([ 'middleware' => 'api', 'prefix' => 'drivers', 'namespace' => 'Api' ], function() {

    Route::post('create', 'DriverController@store');
    Route::post('edit', 'DriverController@update');
    Route::post('delete', 'DriverController@destroy');
    Route::post('index', 'DriverController@index');

});

Route::group([ 'middleware' => 'api', 'prefix' => 'vehicles', 'namespace' => 'Api' ], function() {

    Route::post('create', 'VehicleController@store');
    Route::post('edit', 'VehicleController@update');
    Route::post('delete', 'VehicleController@destroy');
    Route::post('index', 'VehicleController@index');

});

Route::group([ 'middleware' => 'api', 'prefix' => 'bookings', 'namespace' => 'Api' ], function() {

    // booking
    // create booking
    Route::post('create', 'BookingController@create');

    // accept booking
    Route::post('accept', 'BookingController@accept');

    // change booking status booking
    Route::post('booking-status', 'BookingController@updateStatus');

    // in cancel
    Route::post('cancel', 'BookingController@vendorCancel');

    // complete from vendor & rating
    Route::post('rating_by_vendor', 'BookingController@rating_by_vendor');

    // complete from customer & rating
    Route::post('rating_by_customer', 'BookingController@rating_by_customer');

    // booking history
    Route::post('customer/my_history', 'BookingController@customer_my_history');

    Route::post('vendor/my_history', 'BookingController@vendor_my_history');

    Route::post('vendor/customer_request', 'BookingController@vendor_customer_request');

    Route::post('notifications', 'BookingController@userNotification');

});