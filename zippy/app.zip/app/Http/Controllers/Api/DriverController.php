<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Basecode\Classes\Repositories\DriverRepository;

class DriverController extends ApiController {

    public $repository;
    public function __construct(
        DriverRepository $repository

    ) {
        $this->repository = $repository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {

        if ( $error = $this->cvalidate(['vendor_id' => 'required|exists:users,id']) ) return $this->error($error, $error->first());
        $collection = $this->repository->getCollection()->where('vendor_id', request('vendor_id'))->get();

        return $this->data($this->repository->parseCollection($collection), '', 'driver_details');

    }

    /**
     * Store a newly created resource in storage.
     *
     * @return \Illuminate\Http\Response
     */
    public function store() {

        $rules =  [
            'vendor_id' => 'required',
            'name' => 'required',
            'email' => 'required|unique:drivers,email',
            'mobile' => 'required|digits:10|numeric',
            'licence_no' => 'required',
            'licence_pic' => 'required|image',
            'city' => 'required',
            'state' => 'required',
            'pincode' => 'required',
        ];

        if ( $error = $this->cvalidate($rules) ) return $this->error($error, $error->first());

        $model = $this->repository->save($this->repository->getAttrs());

        return $this->data($this->repository->parseModel($model), '', 'driver_details');

    }


    /**
     * Update the specified resource in storage.
     * @return \Illuminate\Http\Response
     */
    public function update() {

        $rules =  [
            'vendor_id' => 'required',
            'driver_id' => 'required|exists:drivers,id',
        ];

        if ( $error = $this->cvalidate($rules) ) return $this->error($error, $error->first());

        $model = $this->repository->find(request('driver_id'));

        $model = $this->repository->update($model);

        return $this->data($this->repository->parseModel($model), '', 'driver_details');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy() {

        $rules =  [
            'vendor_id' => 'required',
            'driver_id' => 'required|exists:drivers,id',
        ];

        if ( $error = $this->cvalidate($rules) ) return $this->error($error, $error->first());

        $model = $this->repository->find(request('driver_id'));

        $this->repository->delete($model);

        return $this->data([], 'Driver removed', 'driver_details');

    }

}
