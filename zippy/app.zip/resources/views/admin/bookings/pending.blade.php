@extends('layouts.master')

@section('header')
    <div class="m-subheader ">
        <div class="d-flex align-items-center">
            <div class="mr-auto">
                <h3 class="m-subheader__title m-subheader__title--separator"> Pending Bookings </h3>
                <ul class="m-subheader__breadcrumbs m-nav m-nav--inline">
                    <li class="m-nav__item m-nav__item--home">
                        <a href="{{ route('admin.dashboard') }}" class="m-nav__link m-nav__link--icon">
                            <i class="m-nav__link-icon la la-home"></i>
                        </a>
                    </li>
                    <li class="m-nav__separator"> - </li>
                    <li class="m-nav__item"><span class="m-nav__link-text">Pending Bookings</span></li>
                </ul>
            </div>
        </div>
    </div>
@stop

@section('content')

    <div class="m-portlet m-portlet--brand m-portlet--head-solid-bg ">
        <div class="m-portlet__head">
            <div class="m-portlet__head-caption">
                <div class="m-portlet__head-title">
                    <span class="m-portlet__head-icon "><i class="flaticon-route"></i></span>
                    <h3 class="m-portlet__head-text">Pending Bookings</h3>
                </div>
            </div>
        </div>
        <div class="m-portlet__body" >
            <table class="table table-sm table-bordered table-hover">
                <thead class="thead-default">
                <tr>
                    <th>#</th>
                    <th>Customer</th>
                    <th>Pickup Address</th>
                    <th>Drop Address</th>
                    <th>Cargo Type</th>
                    <th>Vehicle Type</th>
                    <th>Vehicle Category</th>
                    <th>Distance({{distanceSign()}}.)</th>
                    <th>Amount(₹)</th>
                    <th>Created On</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                @foreach( $collection as $model )
                    <?php
                        if(! $model->customer ) continue;
                        $customer = $model->customer;
                    ?>
                    <tr>
                        <th scope="row">{{ $model->id }}</th>
                        <td>
                            <img
                                style="width: 70px; height:70px"
                                src="{{ getImageUrl($model->customer->image) }}"
                            >
                        </td>
                        <td>{{ $model->pickup_address }}</td>
                        <td>{{ $model->drop_address }}</td>
                        <td>
                            @if( isset($model->cargo_type) && $model->cargo_type && $model->cargo_type->title )
                                {{ $model->cargo_type->title }}
                            @endif
                        </td>
                        <td>
                            @if( isset($model->vehicle_type) && $model->vehicle_type && $model->vehicle_type->title )
                                {{ $model->vehicle_type->title }}
                            @endif
                        </td>
                        <td>
                            @if( isset($model->vehicle_category) && $model->vehicle_category && $model->vehicle_category->title )
                                {{ $model->vehicle_category->title }}
                            @endif
                        </td>
                        <td>{{ $model->total_distance. distanceSign() }}</td>
                        <td>{{ currencySign(). $model->total_amount }}</td>
                        <td>{{ date('d/m/Y', strtotime($model->created_at)) }}</td>
                        <td>
                            @if( isset($vendors_count[$model->id]) )
                                <a title="Request accepted assign vendor" href="{{route('admin.bookings.assign_vendor', $model->id)}}" class="btn m-btn--pill m-btn--air btn-primary btn-sm">
                                    Assign Vendor
                                    <span class="m-badge m-badge--danger">{{$vendors_count[$model->id]}}</span>
                                </a>
                            @else
                                <a title="Manual assign vendor" href="{{route('admin.bookings.custom_assign_vendor', $model->id)}}" class="btn m-btn--pill m-btn--air btn-info btn-sm">
                                    Assign Vendor
                                    <span class="m-badge m-badge--danger">0</span>
                                </a>
                            @endif
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>

    </div>

@stop

@section('style')
    <style>
        .m-portlet.m-portlet--head-sm .m-portlet__head {
            height: 6.1rem;

        }
        .m-portlet:hover{
            box-shadow: 0px 3px 20px 0px #bdc3d4;
        }
    </style>
@stop

@section('script')
    <script>
        $(document).ready(function(){
            $('.booking-menu').addClass('m-menu__item--submenu m-menu__item--open m-menu__item--expanded');
            $('.pendingbooking-menu').addClass('m-menu__item--active');
        });
    </script>
@stop