<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('testPush', function () {

    $devices = [
        'fXcxIprYeh0:APA91bEmy9Z5mfaZEYhooQZPE0TbXwvtM01OwZQJ73HoFccVrkdS7fxfOynFfGwByEmTJU2Rnwk1NEozq6ptIsc4F-VlV1x1eSMEfYUBpu3bjp5KE8gJoC8A_IP611e6PuZlQ3RCxn5w'
    ];

    $key = 'AIzaSyBT_j5MBbutEOYLlDjxMB0A-hhjzqg4bcM';

    sendAndroidPushNotification($devices, [ 'booking_id' => '2', 'category' => 'create_booking' ], $key, true);

});

// Auth::routes();

Route::get('login', 'Auth\LoginController@showLoginForm')->name('login');
Route::post('login', 'Auth\LoginController@login');
Route::post('logout', 'Auth\LoginController@logout')->name('logout');

//Route::get('password/reset', ['as' => 'password.reset', 'uses' => 'Auth\ForgotPasswordController@showLinkRequestForm']);
//Route::post('password/email', ['as' => 'password.email', 'uses' => 'Auth\ForgotPasswordController@sendResetLinkEmail']);
//Route::get('password/reset/{token}', ['as' => 'password.reset.token', 'uses' => 'Auth\ResetPasswordController@showResetForm']);
//Route::post('password/reset', ['as' => 'password.reset.post', 'uses' => 'Auth\ResetPasswordController@reset']);

Route::get('password/reset/{token}', ['as' => 'password.reset', 'uses' => 'Auth\ResetPasswordController@showResetForm']);
Route::get('password/reset', ['as' => 'password.request', 'uses' => 'Auth\ForgotPasswordController@showLinkRequestForm']);

Route::get('/home', 'HomeController@index')->name('admin.dashboard');

Route::group([ 'prefix' => config('app.admin_prefix', 'admin'), 'middleware' => 'admin.auth', 'namespace' => 'Admin' ], function(){

    Route::get('logs', function(){

        if( request('clear') ) {
            \DB::table('logs')->truncate();
            return Redirect::to('admin/logs');
        }

        return view('admin.configurations.logs');
    });

    Route::get('cargos', [ 'as' => 'admin.cargos.index', 'uses' => 'CargotypeController@index' ]);
    Route::get('cargos/create', [ 'as' => 'admin.cargos.create', 'uses' => 'CargotypeController@create' ]);
    Route::post('cargos', [ 'as' => 'admin.cargos.store', 'uses' => 'CargotypeController@store' ]);
    Route::get('cargos/{id}', [ 'as' => 'admin.cargos.show', 'uses' => 'CargotypeController@show' ]);
    Route::get('cargos/{id}/edit', [ 'as' => 'admin.cargos.edit', 'uses' => 'CargotypeController@edit' ]);
    Route::put('cargos/{id}', [ 'as' => 'admin.cargos.update', 'uses' => 'CargotypeController@update' ]);
    Route::get('cargos/{id}/destroy', [ 'as' => 'admin.cargos.delete', 'uses' => 'CargotypeController@destroy' ]);

});

Route::group([ 'prefix' => config('app.admin_prefix', 'admin'), 'middleware' => 'admin.auth', 'namespace' => 'Admin' ], function(){

	Route::get('vehicletypes', [ 'as' => 'admin.vehicletypes.index', 'uses' => 'VehicletypeController@index' ]);
    Route::get('vehicletypes/create', [ 'as' => 'admin.vehicletypes.create', 'uses' => 'VehicletypeController@create' ]);
    Route::post('vehicletypes', [ 'as' => 'admin.vehicletypes.store', 'uses' => 'VehicletypeController@store' ]);
    Route::get('vehicletypes/{id}', [ 'as' => 'admin.vehicletypes.show', 'uses' => 'VehicletypeController@show' ]);
    Route::get('vehicletypes/{id}/edit', [ 'as' => 'admin.vehicletypes.edit', 'uses' => 'VehicletypeController@edit' ]);
    Route::put('vehicletypes/{id}', [ 'as' => 'admin.vehicletypes.update', 'uses' => 'VehicletypeController@update' ]);
    Route::get('vehicletypes/{id}/destroy', [ 'as' => 'admin.vehicletypes.delete', 'uses' => 'VehicletypeController@destroy' ]);

});

Route::group([ 'prefix' => config('app.admin_prefix', 'admin'), 'middleware' => 'admin.auth', 'namespace' => 'Admin' ], function(){

	Route::get('vehiclecategories', [ 'as' => 'admin.vehiclecategories.index', 'uses' => 'VehiclecategoryController@index' ]);
    Route::get('vehiclecategories/create', [ 'as' => 'admin.vehiclecategories.create', 'uses' => 'VehiclecategoryController@create' ]);
    Route::post('vehiclecategories', [ 'as' => 'admin.vehiclecategories.store', 'uses' => 'VehiclecategoryController@store' ]);
    Route::get('vehiclecategories/{id}', [ 'as' => 'admin.vehiclecategories.show', 'uses' => 'VehiclecategoryController@show' ]);
    Route::get('vehiclecategories/{id}/edit', [ 'as' => 'admin.vehiclecategories.edit', 'uses' => 'VehiclecategoryController@edit' ]);
    Route::put('vehiclecategories/{id}', [ 'as' => 'admin.vehiclecategories.update', 'uses' => 'VehiclecategoryController@update' ]);
    Route::get('vehiclecategories/{id}/destroy', [ 'as' => 'admin.vehiclecategories.delete', 'uses' => 'VehiclecategoryController@destroy' ]);    

});

Route::group([ 'prefix' => config('app.admin_prefix', 'admin'), 'middleware' => 'admin.auth', 'namespace' => 'Admin' ], function(){

    Route::get('customers', [ 'as' => 'admin.customers.index', 'uses' => 'CustomerController@index' ]);
    Route::get('customers/create', [ 'as' => 'admin.customers.create', 'uses' => 'CustomerController@create' ]);
    Route::post('customers', [ 'as' => 'admin.customers.store', 'uses' => 'CustomerController@store' ]);
    Route::get('customers/{id}', [ 'as' => 'admin.customers.show', 'uses' => 'CustomerController@show' ]);
    Route::get('customers/{id}/edit', [ 'as' => 'admin.customers.edit', 'uses' => 'CustomerController@edit' ]);
    Route::put('customers/{id}', [ 'as' => 'admin.customers.update', 'uses' => 'CustomerController@update' ]);
    Route::get('customers/{id}/destroy', [ 'as' => 'admin.customers.delete', 'uses' => 'CustomerController@destroy' ]);
    Route::get('search/customers', [ 'as' => 'admin.customers.search', 'uses' => 'CustomerController@search' ]);

});

Route::group([ 'prefix' => config('app.admin_prefix', 'admin'), 'middleware' => 'admin.auth', 'namespace' => 'Admin' ], function(){

    Route::get('vendors', [ 'as' => 'admin.vendors.index', 'uses' => 'VendorController@index' ]);
    Route::get('vendors/create', [ 'as' => 'admin.vendors.create', 'uses' => 'VendorController@create' ]);
    Route::post('vendors', [ 'as' => 'admin.vendors.store', 'uses' => 'VendorController@store' ]);
    Route::get('vendors/{id}', [ 'as' => 'admin.vendors.show', 'uses' => 'VendorController@show' ]);
    Route::get('vendors/{id}/edit', [ 'as' => 'admin.vendors.edit', 'uses' => 'VendorController@edit' ]);
    Route::put('vendors/{id}', [ 'as' => 'admin.vendors.update', 'uses' => 'VendorController@update' ]);
    Route::get('vendors/{id}/destroy', [ 'as' => 'admin.vendors.delete', 'uses' => 'VendorController@destroy' ]);
    Route::get('search/vendors', [ 'as' => 'admin.vendors.search', 'uses' => 'VendorController@search' ]);

    Route::get('vendors/{vendor_id}/drivers', ['uses' => 'DriverController@index_driver', 'as' => 'admin.drivers.index']);
    Route::get('vendors/{vendor_id}/add_driver', ['uses' => 'DriverController@add_driver', 'as' => 'admin.drivers.create']);
    Route::post('vendors/{vendor_id}/add_driver', ['uses' => 'DriverController@store_driver', 'as' => 'admin.drivers.store']);
    Route::get('vendors/{vendor_id}/edit_driver/{driver_id}', ['uses' => 'DriverController@edit_driver', 'as' => 'admin.drivers.edit']);
    Route::put('vendors/{vendor_id}/edit_driver/{driver_id}', ['uses' => 'DriverController@update_driver', 'as' => 'admin.drivers.update']);
    Route::get('vendors/{vendor_id}/delete_driver/{driver_id}', ['uses' => 'DriverController@delete_driver', 'as' => 'admin.drivers.delete']);

    Route::get('vendors/{vendor_id}/vehicles', ['uses' => 'VehicleController@index_vehicle', 'as' => 'admin.vehicles.index']);
    Route::get('vendors/{vendor_id}/add_vehicle', ['uses' => 'VehicleController@add_vehicle', 'as' => 'admin.vehicles.create']);
    Route::post('vendors/{vendor_id}/add_vehicle', ['uses' => 'VehicleController@store_vehicle', 'as' => 'admin.vehicles.store']);
    Route::get('vendors/{vendor_id}/edit_vehicle/{vehicle_id}', ['uses' => 'VehicleController@edit_vehicle', 'as' => 'admin.vehicles.edit']);
    Route::put('vendors/{vendor_id}/edit_vehicle/{vehicle_id}', ['uses' => 'VehicleController@update_vehicle', 'as' => 'admin.vehicles.update']);
    Route::get('vendors/{vendor_id}/delete_vehicle/{vehicle_id}', ['uses' => 'VehicleController@delete_vehicle', 'as' => 'admin.vehicles.delete']);

});

Route::group([ 'prefix' => config('app.admin_prefix', 'admin'), 'middleware' => 'admin.auth', 'namespace' => 'Admin' ], function(){

    Route::get('areas', [ 'as' => 'admin.areas.index', 'uses' => 'AreaController@index' ]);
    Route::get('areas/create', [ 'as' => 'admin.areas.create', 'uses' => 'AreaController@create' ]);
    Route::post('areas', [ 'as' => 'admin.areas.store', 'uses' => 'AreaController@store' ]);
    Route::get('areas/{id}', [ 'as' => 'admin.areas.show', 'uses' => 'AreaController@show' ]);
    Route::get('areas/{id}/edit', [ 'as' => 'admin.areas.edit', 'uses' => 'AreaController@edit' ]);
    Route::put('areas/{id}', [ 'as' => 'admin.areas.update', 'uses' => 'AreaController@update' ]);
    Route::get('areas/{id}/destroy', [ 'as' => 'admin.areas.delete', 'uses' => 'AreaController@destroy' ]);

});

Route::group([ 'prefix' => config('app.admin_prefix', 'admin'), 'middleware' => 'admin.auth', 'namespace' => 'Admin' ], function(){

    Route::get('pages', [ 'as' => 'admin.pages.index', 'uses' => 'PageController@index' ]);
    Route::get('pages/create', [ 'as' => 'admin.pages.create', 'uses' => 'PageController@create' ]);
    Route::post('pages', [ 'as' => 'admin.pages.store', 'uses' => 'PageController@store' ]);
    Route::get('pages/{id}', [ 'as' => 'admin.pages.show', 'uses' => 'PageController@show' ]);
    Route::get('pages/{id}/edit', [ 'as' => 'admin.pages.edit', 'uses' => 'PageController@edit' ]);
    Route::put('pages/{id}', [ 'as' => 'admin.pages.update', 'uses' => 'PageController@update' ]);
    Route::get('pages/{id}/destroy', [ 'as' => 'admin.pages.delete', 'uses' => 'PageController@destroy' ]);

});

Route::group([ 'prefix' => config('app.admin_prefix', 'admin'), 'middleware' => 'admin.auth', 'namespace' => 'Admin' ], function(){

    Route::get('pending/bookings', ['as' => 'admin.bookings.pending', 'uses' => 'BookingController@pending']);
    Route::get('assign/vendors/{id}/bookings', ['as' => 'admin.bookings.assign_vendor', 'uses' => 'BookingController@assign_vendor']);
    Route::post('assign/vendors/{id}/bookings', ['as' => 'admin.bookings.assign_vendor_store', 'uses' => 'BookingController@assign_vendor_store']);

    // custom assign
    Route::get('custom_assign/vendors/{id}/bookings', ['as' => 'admin.bookings.custom_assign_vendor', 'uses' => 'BookingController@assign_vendor']);
    Route::post('custom_assign/vendors/{id}/bookings', ['as' => 'admin.bookings.custom_assign_vendor_store', 'uses' => 'BookingController@assign_vendor_store']);

    Route::get('bookings/index', [ 'as' => 'admin.bookings.index', 'uses' => 'BookingController@index' ]);

    Route::get('bookings/{id}', [ 'as' => 'admin.bookings.show', 'uses' => 'BookingController@show' ]);

});

