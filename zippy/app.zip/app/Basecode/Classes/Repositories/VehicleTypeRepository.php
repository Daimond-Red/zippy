<?php

namespace App\Basecode\Classes\Repositories;

class VehicleTypeRepository extends Repository {

    public $model = '\App\VehicleType';

    public $viewIndex = 'admin.vehicletypes.index';
    public $viewCreate = 'admin.vehicletypes.create';
    public $viewEdit = 'admin.vehicletypes.edit';
    public $viewShow = 'admin.vehicletypes.show';

    public $storeValidateRules = [
        'title' => 'required'
    ];

    public $updateValidateRules = [
        'title' => 'required'
    ];

    public function parseModel($model) {

        $arr = [];
        $arr['vehicle_type_id'] = (string)$this->prepare_field('id', $model);
        $arr['title']           = (string)$this->prepare_field('title', $model);

        return $arr;
    }

}