<?php

namespace App\Basecode\Classes\Repositories;

class DriverRepository extends Repository {

    public $model = '\App\Driver';

    public $viewIndex = 'admin.drivers.index';
    public $viewCreate = 'admin.drivers.create';
    public $viewEdit = 'admin.drivers.edit';
    public $viewShow = 'admin.drivers.show';

    public $storeValidateRules = [
        'name'      => 'required',
        'email'     => 'required|unique:drivers,email',
        'mobile'    => 'required',
        'licence_no' => 'required',
        'licence_pic' => 'required|image',
        'address1' => 'required',
        'address2' => 'required',
        'city' => 'required',
        'state' => 'required',
        'pincode' => 'required',
    ];

    public $updateValidateRules = [

    ];

    public function getAttrs()
    {
        $attrs = parent::getAttrs();

        $uploads = ['licence_pic', 'image'];

        foreach ( $uploads as $upload ) {
            if( request()->hasFile($upload) ){
                $attrs[$upload] = self::upload_file($upload, 'vendors');
            } elseif( $attrs && count($attrs) && array_key_exists($upload, $attrs) ) {
                unset($attrs[$upload]);
            }
        }

        return $attrs;

    }

    public function getRatting($id){
        $ratting = \App\ReviewRating::where('rated_id', $id)->where('type', 'driver')->avg('rating');
        return number_format($ratting, 1, '.', '');
    }


    public function parseModel($model) {

        $arr = [];
        $arr['driver_id'] = (int)$this->prepare_field('id', $model);

        $arr['name']  = (string)$this->prepare_field('name', $model);
        $arr['email']  = (string)$this->prepare_field('email', $model);
        $arr['image']  = (string)$this->prepare_field('image', $model);
        $arr['mobile']  = (string)$this->prepare_field('mobile', $model);
        $arr['rating'] = (string)$this->getRatting($model->id);;
        $arr['licence_no']  = (string)$this->prepare_field('licence_no', $model);
        $arr['licence_pic']  = (string)$this->prepare_field('licence_pic', $model);
        $arr['address1']  = (string)$this->prepare_field('address1', $model);
        $arr['address2']  = (string)$this->prepare_field('address2', $model);
        $arr['city']  = (string)$this->prepare_field('city', $model);
        $arr['state']  = (string)$this->prepare_field('state', $model);
        $arr['pincode']  = (string)$this->prepare_field('pincode', $model);

        $arr['created_at'] = (string)$this->prepare_field('created_at', $model);

        return $arr;
    }

}