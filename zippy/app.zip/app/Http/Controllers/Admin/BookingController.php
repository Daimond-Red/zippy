<?php

namespace App\Http\Controllers\Admin;

use App\Booking;
use App\Basecode\Classes\Repositories\BookingRepository;
use App\Basecode\Classes\Permissions\Permission;
use App\BookingLog;
use App\User;
use Illuminate\Support\Facades\DB;

class BookingController extends BackendController {

    public function __construct(BookingRepository $repository, Permission $permission) {
        $this->repository = $repository;
        $this->permission = $permission;
    }

    public function pending() {

        if(! $this->permission->index() ) return;

        $collection = $this->repository->getCollection()->where('status', Booking::PENDING)->orderBy('updated_at', 'desc')->get();

        $vendors_count = BookingLog::select('booking_id', \DB::raw('count(*) as count'))->groupBy('booking_id')->pluck('count', 'booking_id');

        return view('admin.bookings.pending', compact('collection', 'vendors_count'));

    }

    public function assign_vendor($id) {

        if(! $this->permission->show() ) return;

        $model = $this->repository->find($id);

        // WE CAN ONLY ASSIGN VENDOR IN CASE OF PENDING BOOKING
        // OTHERWISE WE WILL REDIRECT TO DASHBOARD WITH ERROR.
        if( $model->status != Booking::PENDING ) return redirectToDashboard();

        $logs = BookingLog::where('booking_id', $model->id)->with(['vendor', 'driver', 'vehicle'])->get();
        $vendors = $this->repository->getRelatedVendors($model->vehicle_category_id)->toArray();
        $vendorLists = User::where('role', User::VENDOR)->whereIn('id',array_column($vendors, 'id'))->with(['drivers', 'vehicles'])->get()->toArray();

        return view('admin.bookings.assign_vendor', compact('model', 'logs', 'vendorLists'));

    }

    public function assign_vendor_store($id) {

        if(! $this->permission->show() ) return;

        $model = $this->repository->find($id);

        // WE CAN ONLY ASSIGN VENDOR IN CASE OF PENDING BOOKING
        // OTHERWISE WE WILL REDIRECT TO DASHBOARD WITH ERROR.
        if( $model->status != Booking::PENDING ) return redirectToDashboard();
        $vendor_id = 0;
        $driver_id = 0;
        $vehicle_id = 0;
        if(request('vendor_id') > 0){
            $vendor_id = request('vendor_id');
            $driver_id = request('driver_id_'.$vendor_id);
            $vehicle_id = request('vehicle_id_'.$vendor_id);
        }else{
            $log = BookingLog::find(request('id'));
            if(! ($log && ($log->booking_id != request('id'))) ) return redirectToDashboard();

            $vendor_id = $log->vendor_id;
            $driver_id = $log->driver_id;
            $vehicle_id = $log->vehicle_id;
            $log->status = 2;
            $log->save();
        }
        
        $model->vendor_id = $vendor_id;
        $model->driver_id = $driver_id;
        $model->vehicle_id = $vehicle_id;
        $model->status = 2;
        $model->save();

        return $this->repository->redirectBackWithSuccess('Vendor assigned successfully', 'admin.bookings.pending');

    }

    public function index() {

        if(! $this->permission->index() ) return;

        $collection = $this->repository->getCollection()->with(['booking_status'])->where('status', '>', 1)->get();

        return view($this->repository->viewIndex, [
            'collection' => $collection,
            'repository' => $this->repository
        ]);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id) {

        if(! $this->permission->show() ) return;

        $model = $this->repository->find($id);

        return view($this->repository->viewShow, [
            'model'         => $model,
            'repository'    => $this->repository
        ]);

    }

}
