@extends('layouts.master')

@section('header')
    <div class="m-subheader ">
        <div class="d-flex align-items-center">
            <div class="mr-auto">
                <h3 class="m-subheader__title m-subheader__title--separator"> Bookings </h3>
                <ul class="m-subheader__breadcrumbs m-nav m-nav--inline">
                    <li class="m-nav__item m-nav__item--home">
                        <a href="{{ route('admin.dashboard') }}" class="m-nav__link m-nav__link--icon">
                            <i class="m-nav__link-icon la la-home"></i>
                        </a>
                    </li>
                    <li class="m-nav__separator"> - </li>
                    <li class="m-nav__item"><span class="m-nav__link-text"> Bookings </span></li>
                </ul>
            </div>
        </div>
    </div>
@stop

@section('sidebarSearch')
    <form action="{{route('admin.bookings.index')}}" method="GET" id="search-form">

        {!! HTML::vselect('customer_id', ['Please select...'], null, ['label' => 'Customer', 'id' => 'customer-select']) !!}

        {!! HTML::vselect('vendor_id', ['Please select...'], null, ['label' => 'Vendor', 'id' => 'vendor-select']) !!}

        {!! HTML::vselect('status', [ \App\Booking::ACCEPT => 'Accept', \App\Booking::PROCESS => 'In Transit', \App\Booking::COMPLETE => 'Completed'], null) !!}

        <div id="m_datepicker_5" class="input-daterange">
            {!! HTML::vtext('start', null, ['label' => 'Bookings From Date']) !!}
            {!! HTML::vtext('end', null, ['label' => 'Bookings From To']) !!}
        </div>


        <input type="submit" value="search" style="display: none">

    </form>
@stop

@section('content')

    <div class="m-portlet m-portlet--brand m-portlet--head-solid-bg ">
        <div class="m-portlet__head">
            <div class="m-portlet__head-caption">
                <div class="m-portlet__head-title">
                    <span class="m-portlet__head-icon "><i class="flaticon-grid-menu-v2"></i></span>
                    <h3 class="m-portlet__head-text"> Bookings </h3>
                </div>
            </div>
            <div class="m-portlet__head-tools">
                <ul class="m-portlet__nav">
                    <li class="m-portlet__nav-item">
                        <button
                                id="m_quick_sidebar_toggle"
                                class="m-portlet__nav-link btn btn-light m-btn m-btn--pill m-btn--air"
                        >
                            Search
                        </button>
                    </li>
                </ul>
            </div>
        </div>
        <div class="m-portlet__body" >
            <table class="table table-sm table-bordered table-hover">
                <thead class="thead-default">
                <tr>
                    <th>#</th>
                    <th>Customer</th>
                    <th>Cargo Type</th>
                    <th>Vehicle Type</th>
                    <th>Vehicle Category</th>
                    <th>Distance({{distanceSign()}}.)</th>
                    <th>Amount(₹)</th>
                    <th>Status</th>
                    <th>Created On</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                @foreach( $collection as $model )
                    <?php
                    if(! $model->customer ) continue;
                    $customer = $model->customer;
                    ?>
                    <tr>
                        <th scope="row">{{ $model->id }}</th>
                        <td>
                            <img
                                    style="width: 70px; height:70px"
                                    src="{{ getImageUrl($model->customer->image) }}"
                            >
                        </td>
                        <td>
                            @if( isset($model->cargo_type) && $model->cargo_type && $model->cargo_type->title )
                                {{ $model->cargo_type->title }}
                            @endif
                        </td>
                        <td>
                            @if( isset($model->vehicle_type) && $model->vehicle_type && $model->vehicle_type->title )
                                {{ $model->vehicle_type->title }}
                            @endif
                        </td>
                        <td>
                            @if( isset($model->vehicle_category) && $model->vehicle_category && $model->vehicle_category->title )
                                {{ $model->vehicle_category->title }}
                            @endif
                        </td>
                        <td>{{ $model->total_distance. distanceSign() }}</td>
                        <td>{{ currencySign(). $model->total_amount }}</td>
                        <td>
                            <span class="m-badge m-badge--primary m-badge--wide" >{{ $model->booking_status->title  }}</span>
                        </td>
                        <td>{{ date('d/m/Y', strtotime($model->created_at)) }}</td>
                        <td>
                            <a href="{{ route('admin.bookings.show', $model->id) }}" class="btn m-btn--pill m-btn--air btn-primary btn-sm">
                                View Details
                            </a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>

    </div>

@stop

@section('style')
    <style>
        .m-portlet.m-portlet--head-sm .m-portlet__head {
            height: 6.1rem;

        }
        .m-portlet:hover{
            box-shadow: 0px 3px 20px 0px #bdc3d4;
        }
        .select2-container{
            display: block;
        }
        .input-daterange input {
             text-align: left;
        }
    </style>
@stop

@section('script')
    <script>
        $(document).ready(function(){
            $('.booking-menu').addClass('m-menu__item--submenu m-menu__item--open m-menu__item--expanded');
            $('.bookinglist-menu').addClass('m-menu__item--active');

            $("#customer-select").select2({
                width: "off",
                ajax: {
                    url: "{{route('admin.customers.search')}}",
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        return {
                            q: params.term, // search term
                            page: params.page
                        };
                    },
                    processResults: function(data, page) {
                        return {
                            results: data.items
                        };
                    },
                    cache: true
                }
            });

            $("#vendor-select").select2({
                width: "off",
                ajax: {
                    url: "{{route('admin.vendors.search')}}",
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        return {
                            q: params.term, // search term
                            page: params.page
                        };
                    },
                    processResults: function(data, page) {
                        return {
                            results: data.items
                        };
                    },
                    cache: true
                }
            });

            $('#m_datepicker_5').datepicker({
                todayHighlight: true,
                format:'yyyy-mm-dd',
                templates: {
                    leftArrow: '<i class="la la-angle-left"></i>',
                    rightArrow: '<i class="la la-angle-right"></i>'
                }
            });

        });
    </script>
@stop