<?php

use Twilio\Rest\Client;

function generateOTP(){
    return mt_rand(1111, 9999);
}

function sendOtp($mobile_no, $message = '') {

    $otp = generateOTP();

    if(!$message) $message = 'Please enter '.$otp.' as your one time verification for mobile number. Team Zippy';

    $sender = 'ZippyO';
    $route = '4';
    $country = '91';
    $mobiles = $mobile_no;
    $authkey = '182030AOM3FNio06Wb5a7acf5c';

    try{
        $api = "http://api.msg91.com/api/sendhttp.php?sender=". $sender;

        $api .= '&route='. $route;
        $api .= '&country='. $country;
        $api .= '&message='. $message;
        $api .= '&mobiles='. $mobiles;
        $api .= '&authkey='. $authkey;

        $client = new \GuzzleHttp\Client();
        $res = $client->request('GET', $api);

        if( $res->getStatusCode() != 200 ) return [];

        $res = (array)json_decode($res->getBody());

    } catch ( Exception $e ) {

    }

    return $otp;
}

function getImageUrl($image) {
    if(!$image) return asset('uploads/not-found.png');
    return asset($image);
}

function currencySign() {
    return '₹';
}

function distanceSign() {
    return 'Km';
}

function redirectToDashboard() {
    return redirect()->route('admin.dashboard')->withErrors('Something went wrong');
}

if (! function_exists('sendAndroidPushNotification')) {

    function sendAndroidPushNotification($token, $notification, $otherData) {
        try {

            ini_set('display_errors', '1');
            error_reporting(E_ALL);
            // if(!$ids) return;

            $ch = curl_init("https://fcm.googleapis.com/fcm/send");

            //This array contains, the token and the notification. The 'to' attribute stores the token.
            $arrayToSend = array('to' => $token, 'notification' => $notification,'priority'=>'high');
            if(!is_null($otherData)){
                $otkey["d"] = $otherData;
                $arrayToSend['data']= $otkey;
            }
            //Generating JSON encoded string form the above array.
            $json = json_encode($arrayToSend);
            //Setup headers:

            $fire_base_api_key = setting('admin.firebase_api_key');

            $headers = array();
            $headers[] = 'Content-Type: application/json';
            $headers[] = 'Authorization: key='. $fire_base_api_key;

            //Setup curl, add headers and post parameters.
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
            curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
            curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);       

            //Send the request
            $response = curl_exec($ch);

            //Close request
            curl_close($ch);
            // print_r($response);exit;
            return $response;


        } catch (Exception $e) {
            // echo $e->getMesssage();
            // die;
        }
    }

}

if (! function_exists('sendIOSPushNotification')) {

    function sendIOSPushNotification($deviceToken, $data, $otherData) {
        if(is_null($deviceToken) || $deviceToken == '' || strlen($deviceToken) < 64){
            return true;
        }
        $mode = 'sandbox';
        $PEM = '/var/www/html/';
        $passphrase = '123456';
        $ctx = stream_context_create();

        stream_context_set_option($ctx, 'ssl', 'local_cert', $PEM);

        stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);

        if($mode == 'sandbox') {
            // Open a connection to the APNS server
            $fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);
        } else {
            // Open a connection to the APNS server
            $fp = stream_socket_client('ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);
        }

        // Put your alert message here:
        $message = $data['message'];

        $body['aps'] = array(
            'alert' => array(
                // 'title' => $data['title'],
                'body' => $message,
                'action-loc-key' => 'zippy',
            ),
            'badge' => 0,
            'sound' => 'default',
            // 'body' => $data['data'],
            );
        if(!is_null($otherData)){
            $body['aps']['data'] = $otherData;
        }

        // Encode the payload as JSON
        $payload = json_encode($body);

        // Build the binary notification
        $msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;

        // Send it to the server
        $result = fwrite($fp, $msg, strlen($msg));

        // Close the connection to the server
        fclose($fp);
        return true;
    }

    function sendPush($user, $data, $otherData = null) {
        try {
            if( $user['device_type'] == 'ios' ) { 
            // WILL SEND PUSH NOTIFICATIONS TO IOS DEVICE.
                sendIOSPushNotification($user['device_token'], $data, $otherData);
            } else { 
            // WILL SEND PUSH NOTIFICATIONS TO ANDROID DEVICE
                sendAndroidPushNotification($user['device_token'], $data, $otherData);
            }
        } catch (Exception $e) {
             echo $e->getMessage();
        }
    }

}